import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react'
import { buildMockState } from '../data/mockData'
import type { HomeState } from '../types'

// One shared copy of the home state for every page.
//
// - Loads from the backend (/api/home-state) and refreshes every minute.
// - If the backend isn't running (plain `npm run dev`), it quietly uses demo data.
// - `update` changes the screen immediately; `send` tells the backend to
//   actually do it. Until a service is connected, its backend function just
//   logs the request, so buttons are safe to press.
// - If the backend says the device isn't signed in, `lock` switches and the
//   app shows the passcode screen instead.
// - If a button press doesn't reach the device, a message says so and the
//   screen snaps back to the real status — it never pretends it worked.

export type LockState = 'open' | 'locked' | 'setup'

interface HomeContextValue {
  data: HomeState | null
  live: boolean
  lock: LockState
  unlock: (passcode: string) => Promise<'ok' | 'wrong' | 'setup'>
  update: (fn: (s: HomeState) => HomeState) => void
  /** Tell the backend to do something. `refresh` reloads real status a few seconds later. */
  send: (path: string, body: unknown, opts?: { refresh?: boolean }) => void
}

const HomeContext = createContext<HomeContextValue | null>(null)
const REFRESH_MS = 60_000

export function HomeProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<HomeState | null>(null)
  const [live, setLive] = useState(false)
  const [lock, setLock] = useState<LockState>('open')
  const [reloadKey, setReloadKey] = useState(0)
  const [toast, setToast] = useState<{ id: number; text: string } | null>(null)
  const liveRef = useRef(false)
  liveRef.current = live

  useEffect(() => {
    if (!toast) return
    const t = setTimeout(() => setToast(null), 6000)
    return () => clearTimeout(t)
  }, [toast])

  const warn = useCallback((text: string) => setToast({ id: Date.now(), text }), [])

  useEffect(() => {
    let cancelled = false
    async function load() {
      try {
        const res = await fetch('/api/home-state')
        if (res.status === 401) {
          const body = await res.json().catch(() => ({}))
          if (!cancelled) { setLock(body.setup ? 'setup' : 'locked'); setData(null) }
          return
        }
        if (!res.ok) throw new Error(String(res.status))
        const state = (await res.json()) as HomeState
        if (!cancelled) { setData(state); setLive(true); setLock('open') }
      } catch {
        if (!cancelled) { setData((prev) => prev ?? buildMockState()); setLive(false) }
      }
    }
    void load()
    const timer = setInterval(load, REFRESH_MS)
    return () => { cancelled = true; clearInterval(timer) }
  }, [reloadKey])

  const unlock = useCallback(async (passcode: string) => {
    const res = await fetch('/api/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ passcode }),
    })
    if (res.ok) { setReloadKey((k) => k + 1); return 'ok' as const }
    const body = await res.json().catch(() => ({}))
    return body.error === 'setup' ? 'setup' as const : 'wrong' as const
  }, [])

  const update = useCallback((fn: (s: HomeState) => HomeState) => {
    setData((prev) => (prev ? fn(prev) : prev))
  }, [])

  const send = useCallback((path: string, body: unknown, opts?: { refresh?: boolean }) => {
    const service = path.split('/')[0]
    const name = service.charAt(0).toUpperCase() + service.slice(1)
    // Undo the on-screen change by reloading the real status
    const revert = () => {
      if (liveRef.current) setReloadKey((k) => k + 1)
      else setData(buildMockState())
    }
    if (!liveRef.current) {
      warn('Demo mode — the dashboard isn\'t connected, so nothing was sent.')
      setTimeout(revert, 1500)
      return
    }
    fetch(`/api/${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
      .then(async (res) => {
        if (res.status === 401) { setLock('locked'); return }
        const json = await res.json().catch(() => ({}))
        if (!res.ok) {
          warn(`${name} didn't respond: ${json.error ?? `error ${res.status}`}. Nothing changed.`)
          revert()
          return
        }
        if (json.connected === false) {
          warn(`${name} isn't connected yet — nothing was sent.`)
          setTimeout(revert, 1500)
          return
        }
        if (opts?.refresh) setTimeout(() => setReloadKey((k) => k + 1), 3000)
      })
      .catch(() => {
        warn(`Couldn't reach the dashboard's backend — check the internet connection. Nothing was sent.`)
        revert()
      })
  }, [warn])

  return (
    <HomeContext.Provider value={{ data, live, lock, unlock, update, send }}>
      {children}
      <div aria-live="assertive" className="pointer-events-none fixed inset-x-0 bottom-5 z-50 flex justify-center px-4">
        {toast && (
          <div key={toast.id} role="alert" className="pointer-events-auto flex max-w-md items-start gap-3 rounded-xl border border-critical/40 bg-surface-raised px-4 py-3 text-sm text-ink shadow-2xl shadow-black/50">
            <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-critical" />
            <span className="flex-1">{toast.text}</span>
            <button onClick={() => setToast(null)} className="text-ink-faint hover:text-ink" aria-label="Dismiss">✕</button>
          </div>
        )}
      </div>
    </HomeContext.Provider>
  )
}

export function useHome(): HomeContextValue {
  const ctx = useContext(HomeContext)
  if (!ctx) throw new Error('useHome must be used inside <HomeProvider>')
  return ctx
}
